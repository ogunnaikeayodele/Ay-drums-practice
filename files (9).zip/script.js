// AY DRUMS portfolio: vanilla JavaScript
document.addEventListener("DOMContentLoaded", () => {
  const header = document.getElementById("header");
  const menuBtn = document.getElementById("menuBtn");
  const navLinks = document.getElementById("navLinks");
  const links = navLinks.querySelectorAll("a");

  // Footer year
  document.getElementById("year").textContent = new Date().getFullYear();

  // Sticky header background
  const onScroll = () => header.classList.toggle("scrolled", window.scrollY > 40);
  onScroll();
  window.addEventListener("scroll", onScroll, { passive: true });

  // Mobile menu
  const setMenu = (open) => {
    navLinks.classList.toggle("open", open);
    menuBtn.setAttribute("aria-expanded", open);
    menuBtn.setAttribute("aria-label", open ? "Close menu" : "Open menu");
  };
  menuBtn.addEventListener("click", () => setMenu(!navLinks.classList.contains("open")));
  links.forEach((a) => a.addEventListener("click", () => setMenu(false)));

  // Highlight the current section in the nav
  const sections = document.querySelectorAll("main section[id]");
  const navObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        links.forEach((a) => a.classList.toggle("active", a.getAttribute("href") === "#" + entry.target.id));
      }
    });
  }, { rootMargin: "-45% 0px -50% 0px" });
  sections.forEach((s) => navObserver.observe(s));

  // Scroll reveal (about, projects, contact) and skill bars
  document.querySelectorAll(".about-grid > *, .card, .contact-grid > *").forEach((el) => el.classList.add("reveal"));
  const fills = document.querySelectorAll(".fill");
  fills.forEach((f) => f.style.setProperty("--w", f.dataset.level + "%"));

  const revealObserver = new IntersectionObserver((entries, obs) => {
    entries.forEach((entry) => {
      if (!entry.isIntersecting) return;
      entry.target.classList.add("visible");
      entry.target.querySelectorAll?.(".fill").forEach((f) => (f.style.width = f.dataset.level + "%"));
      obs.unobserve(entry.target);
    });
  }, { threshold: 0.15 });
  document.querySelectorAll(".reveal").forEach((el) => revealObserver.observe(el));

  const skillsObserver = new IntersectionObserver((entries, obs) => {
    entries.forEach((entry) => {
      if (!entry.isIntersecting) return;
      fills.forEach((f) => (f.style.width = f.dataset.level + "%"));
      obs.disconnect();
    });
  }, { threshold: 0.25 });
  skillsObserver.observe(document.querySelector(".skills-grid"));

  // Contact form: validate, then open the visitor's email app (no backend needed)
  const form = document.getElementById("contactForm");
  const status = document.getElementById("formStatus");
  const RECEIVER = "hello@example.com"; // <-- change to your real email address

  const check = (input) => {
    const field = input.closest(".field");
    const error = field.querySelector(".error");
    let msg = "";
    if (!input.value.trim()) msg = "Please fill in this field.";
    else if (input.type === "email" && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input.value)) msg = "Enter a valid email address.";
    field.classList.toggle("invalid", Boolean(msg));
    error.textContent = msg;
    return !msg;
  };

  form.querySelectorAll("input, textarea").forEach((input) => input.addEventListener("input", () => check(input)));

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const valid = [...form.querySelectorAll("input, textarea")].map(check).every(Boolean);
    if (!valid) {
      status.textContent = "";
      return;
    }
    const name = document.getElementById("name").value.trim();
    const body = `${document.getElementById("message").value.trim()}\n\nFrom: ${name} (${document.getElementById("email").value.trim()})`;
    window.location.href = `mailto:${RECEIVER}?subject=${encodeURIComponent("Website enquiry from " + name)}&body=${encodeURIComponent(body)}`;
    status.textContent = "Thanks, " + name + ". Your email app is opening to send the message.";
    form.reset();
  });
});
